
import Foundation
//how many buckets need if there know area to cover
var width : Float = 1.5
var height : Float = 2.3
var newArea = (width * height) / 1.5

var bucketsOfPaint: Int {
    get{
        var roundedBuckets = ceil(newArea)
        return Int(roundedBuckets)
    }
// if there are 4 buckets --area covered with paint?
    //area = 4/1.5
    set{
    let totalAreaCovered = Float(newValue) * 1.5
        print("The amount of paint can cover (if there are 8 bucket) is \(totalAreaCovered)")
    }


}
print("For width 1.5 and height 2.3 requires bucket:",bucketsOfPaint)
//amount covered for 8 bucket
bucketsOfPaint  = 8

